import unittest


class PillowTests(unittest.TestCase):
    """
    Can we start moving the test suite here?
    """

    def test_suite_should_move_here(self):
        """
        Great idea!
        """
        assert True is True


if __name__ == '__main__':
    unittest.main()
